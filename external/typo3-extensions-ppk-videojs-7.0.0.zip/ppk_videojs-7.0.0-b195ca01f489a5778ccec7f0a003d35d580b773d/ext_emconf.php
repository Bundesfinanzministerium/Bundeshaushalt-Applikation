<?php

$EM_CONF[$_EXTKEY] = [
    'title' => 'Video.JS - HTML5 media player',
    'description' => 'A small fe plugin to render html5 and flash videos based on video.js',
    'category' => 'plugin',
    'author' => 'Heiko Hardt',
    'author_email' => 'heiko.hardt@pixelpark.com',
    'author_company' => 'Pixelpark AG',
    'state' => 'stable',
    'uploadfolder' => '1',
    'createDirs' => '',
    'clearCacheOnLoad' => 0,
    'version' => '7.0.0',
    'constraints' => [
        'depends' => [
            'typo3' => '6.2.0-9.5.99',
        ],
        'conflicts' => [],
        'suggests' => [],
    ],
];

<?php
namespace PPKOELN\PpkVideojs\Controller;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */
use TYPO3\CMS\Core\Resource\FileReference;
use TYPO3\CMS\Core\Utility\GeneralUtility;

/**
 * Class VideoController
 *
 * @version    $Id$
 * @copyright  Copyright belongs to the respective authors
 * @license    http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @package    PPKOELN\PpkVideojs
 * @subpackage Controller
 *
 * @author     Heiko Hardt <heiko.hardt@pixelpark.com>
 */
class VideoController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * @var \TYPO3\CMS\Core\Resource\FileRepository
     */
    protected $fileRepository;

    /**
     * Initializes file repository
     *
     * @return void
     */
    public function initializeAction()
    {
        $this->fileRepository = GeneralUtility::makeInstance(\TYPO3\CMS\Core\Resource\FileRepository::class);
    }

    /**
     * Rendering show action
     *
     * @return void
     */
    public function showAction()
    {
        $this->view->assign('poster', $this->getFileReference('poster'));
        $this->view->assign('videoMp4', $this->getFileReference('mp4'));
        $this->view->assign('videoWebm', $this->getFileReference('webm'));
        $this->view->assign('videoOgv', $this->getFileReference('ogv'));
        $this->view->assign('captionEnglish', $this->getFileReference('captione'));
        $this->view->assign('captionGerman', $this->getFileReference('captiond'));
    }

    /**
     * Get file reference from this content object
     *
     * @param string $fieldName
     * @return FileReference|null
     */
    private function getFileReference(string $fieldName)
    {
        $references = $this->fileRepository->findByRelation(
            'tt_content',
            $fieldName,
            (int) $this->configurationManager->getContentObject()->data['uid']
        );
        return reset($references) ?: null;
    }
}

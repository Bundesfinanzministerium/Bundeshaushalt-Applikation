<?php
namespace PPKOELN\PpkVideojs\Tests\Unit\Controller;

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

/**
 * Test case for class VideoControllerTest.
 *
 * @version    $Id$
 * @copyright  Copyright belongs to the respective authors
 * @license    http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @package    PPKOELN\PpkVideojs
 * @subpackage Tests\Unit\Controller
 *
 * @author     Heiko Hardt <heiko.hardt@pixelpark.com>
 */
class VideoControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{

    /**
     * Main fixture object
     *
     * @var \PPKOELN\PpkVideojs\Controller\VideoController
     */
    protected $fixture = null;

    /**
     * Setup tests
     *
     * @return null
     */
    protected function setUp()
    {

        $this->fixture = $this->getMock(
            '\\PPKOELN\\PpkVideojs\\Controller\\VideoController',
            ['request', 'redirect', 'forward', 'addFlashMessage'],
            [],
            '',
            false
        );

        return null;
    }

    /**
     * Tear down tests
     *
     * @return null
     */
    protected function tearDown()
    {

        unset($this->subject);

        return null;
    }

    /**
     * Testing initial action
     *
     * @test
     * @return null
     */
    public function initializeActionShouldReturnNull()
    {

        // mock request
        $request = $this->getMock(\TYPO3\CMS\Extbase\Mvc\Web\Request::class, []);
        $request->expects($this->any())->method('getControllerExtensionKey')->will($this->returnValue('ppk_videojs'));
        $this->inject($this->fixture, 'request', $request);

        $response = $this->getMock(\TYPO3\CMS\Extbase\Mvc\Web\Response::class, []);
        $response->expects($this->any())->method('addAdditionalHeaderData')->will($this->returnValue('TRUE'));
        $this->inject($this->fixture, 'response', $response);

        $this->fixture->initializeAction();

        return null;
    }

    /**
     * Testing show action
     *
     * @test
     * @return null
     */
    public function showActionShouldReturnNull()
    {
        $this->assertSame(null, $this->fixture->showAction());
        return null;
    }
}

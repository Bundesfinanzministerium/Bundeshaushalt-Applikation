<?php
namespace PPKOELN\PpkFeedback\Controller;

    /***************************************************************
     *
     *  Copyright notice
     *
     *  (c) 2015 Vanessa Kestering <Vanessa.Kestering@publicispixelpark.de>, Pixelpark AG
     *
     *  All rights reserved
     *
     *  This script is part of the TYPO3 project. The TYPO3 project is
     *  free software; you can redistribute it and/or modify
     *  it under the terms of the GNU General Public License as published by
     *  the Free Software Foundation; either version 3 of the License, or
     *  (at your option) any later version.
     *
     *  The GNU General Public License can be found at
     *  http://www.gnu.org/copyleft/gpl.html.
     *
     *  This script is distributed in the hope that it will be useful,
     *  but WITHOUT ANY WARRANTY; without even the implied warranty of
     *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
     *  GNU General Public License for more details.
     *
     *  This copyright notice MUST APPEAR in all copies of the script!
     ***************************************************************/

/**
 * FeedbackControllerTest
 */
class FeedbackControllerTest extends \TYPO3\CMS\Core\Tests\UnitTestCase
{

    /**
     * @var \PPKOELN\PpkFeedback\Controller\FeedbackController
     */
    protected $subject = null;

    protected function setUp()
    {
        $this->subject = $this->getMock(
            'PPKOELN\\PpkFeedback\\Controller\\FeedbackController',
            array('redirect', 'forward', 'addFlashMessage'),
            array(),
            '',
            false
        );
    }

    protected function tearDown()
    {
        unset($this->subject);
    }

    /*******************************************************************************************************************
     * finds topics in repository
     ******************************************************************************************************************/

    /**
     * @test
     */
    public function indexShouldShowAllTopics()
    {

        // Stub Language service
        $GLOBALS['LANG'] = $this->getMock('TYPO3\\CMS\\Lang\\LanguageService', array('lang'), array(), '', false);
        $GLOBALS['LANG']->method('lang')->will($this->returnValue('de'));

        // Stub
        $allTopics = $this->getMock('TYPO3\\CMS\\Extbase\\Persistence\\ObjectStorage', array(), array(), '', false);

        // Mock
        $topicRepository = $this->getMock('PPKOELN\\PpkFeedback\\Domain\\Repository\\TopicRepository', array('findAll'), array(), '', false);
        $topicRepository->expects($this->once())->method('findAll')->will($this->returnValue($allTopics));
        $this->inject($this->subject, 'topicRepository', $topicRepository);

        // Mock
        $view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
        $view->expects($this->at(0))->method('assign')->with('topics', $allTopics);
        $this->inject($this->subject, 'view', $view);

        $this->subject->indexAction();
    }


    /*******************************************************************************************************************
     * assigns view
     ******************************************************************************************************************/

    /**
     * @test
     */
    public function successfulSubmitShouldAssignFeedback()
    {

        $topic = new \PPKOELN\PpkFeedback\Domain\Model\Topic();
        $topic->setEmail('vany@company.de');

        $feedback = new \PPKOELN\PpkFeedback\Domain\Model\Dto\Feedback();
        $feedback->setTopic($topic);

        // stubben des mail krams
        $serviceMailStub = $this->getMockBuilder('PPKOELN\\PpkFeedback\\Service\\Mail')
            ->disableOriginalConstructor()
            ->getMock();
        $serviceMailStub->method('sendMail')->willReturn(true);
        $this->inject($this->subject, 'mailService', $serviceMailStub);

        // stubben des template krams
        $serviceTemplateStub = $this->getMockBuilder('PPKOELN\\PpkFeedback\\Service\\Template')
            ->disableOriginalConstructor()
            ->getMock();
        $serviceTemplateStub->method('rendererTemplate')->willReturn(true);
        $this->inject($this->subject, 'templateService', $serviceTemplateStub);

        $view = $this->getMock('TYPO3\\CMS\\Extbase\\Mvc\\View\\ViewInterface');
        $view->expects($this->once())->method('assign')->with('feedback', $feedback);
        $this->inject($this->subject, 'view', $view);

        $this->subject->submitAction($feedback);
    }
}

<?php
if (!defined('TYPO3_MODE')) {
    die('Access denied.');
}

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::configurePlugin(
    'PPKOELN.' . $_EXTKEY,
    'Pi1',
    array(
        'Feedback' => 'index, submit',
    ),
    // non-cacheable actions
    array(
        'Feedback' => 'submit',
    )
);

/***************
 * Adding dispatcher for feedback ajax support
 */
$TYPO3_CONF_VARS['FE']['eID_include']['ppkFeedback'] =
    \TYPO3\CMS\Core\Utility\ExtensionManagementUtility::extPath('ppk_feedback')
    . 'Resources/Private/Php/EidDispatcher/Feedback.php';

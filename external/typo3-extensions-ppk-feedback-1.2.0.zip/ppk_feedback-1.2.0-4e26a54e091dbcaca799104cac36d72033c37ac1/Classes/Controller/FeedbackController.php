<?php

/*
 * This file is part of the TYPO3 CMS project.
 *
 * It is free software; you can redistribute it and/or modify it under
 * the terms of the GNU General Public License, either version 2
 * of the License, or any later version.
 *
 * For the full copyright and license information, please read the
 * LICENSE.txt file that was distributed with this source code.
 *
 * The TYPO3 project - inspiring people to share!
 */

namespace PPKOELN\PpkFeedback\Controller;

/**
 * Class FeedbackController
 *
 * @version    $Id$
 * @copyright  Copyright belongs to the respective authors
 * @license    http://www.gnu.org/licenses/gpl.html GNU General Public License, version 3 or later
 *
 * @package    PPKOELN\PpkFeedback
 * @subpackage Controller
 *
 * @author     Vanessa Kestering <Vanessa.Kestering@publicispixelpark.de>
 */
class FeedbackController extends \TYPO3\CMS\Extbase\Mvc\Controller\ActionController
{
    /**
     * topicRepository
     *
     * @var \PPKOELN\PpkFeedback\Domain\Repository\TopicRepository
     * @inject
     */
    protected $topicRepository = null;

    /**
     * Template Service
     *
     * @var \PPKOELN\PpkFeedback\Service\Template
     * @inject
     */
    protected $templateService = null;

    /**
     * Mail Service
     *
     * @var \PPKOELN\PpkFeedback\Service\Mail
     * @inject
     */
    protected $mailService = null;

    /**
     * Initialize error action for ajax call
     */
    public function initializeAjaxAction()
    {
        $this->errorMethodName = 'errorAjaxAction';
    }

    /**
     * Main action
     *
     * @return null
     */
    public function indexAction()
    {
        $this->view->assign('topics', $this->topicRepository->findAll());
        $this->view->assign('language', $GLOBALS['TSFE']->lang);

        return null;
    }

    /**
     * @param \PPKOELN\PpkFeedback\Domain\Model\Dto\Feedback $feedback
     *
     * @return null
     */
    public function submitAction(\PPKOELN\PpkFeedback\Domain\Model\Dto\Feedback $feedback)
    {
        // sending mail
        $this->mailService->sendMail(
            array($this->settings['mail']['fromMail'] => $this->settings['mail']['fromTxt']),
            array($feedback->getTopic()->getEmail()),
            $this->settings['mail']['subject'],
            $this->templateService->rendererTemplate('Feedback', 'html', $feedback),
            null,
            null
        );

        $this->view->assign('feedback', $feedback);

        return null;
    }

    /**
     * @param \PPKOELN\PpkFeedback\Domain\Model\Dto\Feedback $feedback
     *
     * @return null
     */
    public function ajaxAction(\PPKOELN\PpkFeedback\Domain\Model\Dto\Feedback $feedback)
    {
        // sending mail
        $this->mailService->sendMail(
            array($this->settings['mail']['fromMail'] => $this->settings['mail']['fromTxt']),
            array($feedback->getTopic()->getEmail()),
            $this->settings['mail']['subject'],
            $this->templateService->rendererTemplate('Feedback', 'html', $feedback),
            null,
            null
        );

        return json_encode(
            array(
                'status' => 'ok',
            )
        );
    }

    /**
     * Error action
     *
     * @return string
     */
    public function errorAjaxAction()
    {
        /** @var \TYPO3\CMS\Extbase\Error\Result $eins */
        $errorResult = $this->arguments
            ->getValidationResults();

        $errors = $errorResult
            ->forProperty('feedback')
            ->getFlattenedErrors();

        $result = array();

        foreach ($errors as $key => $value) {
            foreach ($value as $error) {
                $result[] = array(
                    'field'   => $key,
                    'message' => $GLOBALS['LANG']
                        ->sL(
                            'LLL:EXT:ppk_feedback/Resources/Private/Language/locallang.xlf:Error.'
                            . $key . '.' . $error->getCode()
                        ),
                );
            }
        }

        return json_encode(
            array(
                'status' => 'error',
                'errors' => $result,
            )
        );
    }
}

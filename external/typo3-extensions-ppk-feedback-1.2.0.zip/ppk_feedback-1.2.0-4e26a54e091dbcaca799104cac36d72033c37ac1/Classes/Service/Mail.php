<?php

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015 Vanessa Kestering <Vanessa.Kestering@publicispixelpark.de>, Pixelpark AG
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

namespace PPKOELN\PpkFeedback\Service;

/**
 * Class Mail
 *
 * @package PPKOELN\PpkFeedback\Service
 */
class Mail implements \TYPO3\CMS\Core\SingletonInterface
{
    /**
     * @param array $from
     * @param array $to
     * @param string $subject
     * @param string $bodyHtm
     * @param string $bodyTxt
     * @param array $images
     *
     * @return bool
     */
    public function sendMail($from = array(), $to = array(), $subject = '', $bodyHtm = '', $bodyTxt = '')
    {
        /* @var $mail \TYPO3\CMS\Core\Mail\MailMessage */
        $mail = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Core\\Mail\\MailMessage');

        $mail->setContentType(trim($bodyHtm) !== '' ? 'text/html' : 'text/plain');
        $mail->setFrom($from);
        $mail->setTo($to);
        $mail->setSubject($subject);

        if (trim($bodyHtm) !== '') {
            $mail->setBody($bodyHtm);
            if (trim($bodyTxt) != '') {
                $mail->addPart(trim($bodyTxt));
            }
        } else {
            $mail->setBody($bodyTxt);
        }

        $mail->send();

        return $mail->isSent();
    }
}

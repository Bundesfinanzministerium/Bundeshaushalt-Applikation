<?php

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2015 Vanessa Kestering <Vanessa.Kestering@publicispixelpark.de>, Pixelpark AG
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

namespace PPKOELN\PpkFeedback\Service;

/**
 * Class Template
 *
 * @package PPKOELN\PpkFeedback\Service
 */
class Template implements \TYPO3\CMS\Core\SingletonInterface
{
    /**
     * @param string $template
     * @param string $format
     * @param array $options
     *
     * @return string
     */
    public function rendererTemplate($template = '', $format = '', $options = array())
    {
        $objectManager =
            \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');
        $configurationManager = $objectManager->get('TYPO3\\CMS\\Extbase\\Configuration\\ConfigurationManager');
        $configuration = $configurationManager->getConfiguration(
            \TYPO3\CMS\Extbase\Configuration\ConfigurationManagerInterface::CONFIGURATION_TYPE_FRAMEWORK
        );

        $templateRootPath = \TYPO3\CMS\Core\Utility\GeneralUtility::getFileAbsFileName(
            $configuration['view']['templateRootPaths'][0] . '/Emails/'
        );

        /** @var \TYPO3\CMS\Fluid\View\StandaloneView $view */
        $view = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Fluid\\View\\StandaloneView');
        $view->setFormat($format == 'html' ? 'html' : 'txt');

        $view->setTemplatePathAndFilename($templateRootPath . $template . '.' . $format);

        $view->assign('options', $options);

        return $view->render();
    }
}

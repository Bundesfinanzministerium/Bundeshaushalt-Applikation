<?php

\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
    'ppk_feedback',
    'Configuration/TypoScript',
    'Feedback-Formular'
);

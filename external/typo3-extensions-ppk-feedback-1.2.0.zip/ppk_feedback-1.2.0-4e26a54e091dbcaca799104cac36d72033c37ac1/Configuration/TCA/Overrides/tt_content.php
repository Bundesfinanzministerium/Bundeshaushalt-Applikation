<?php

\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'ppk_feedback',
    'Pi1',
    'Feedback-Formular'
);

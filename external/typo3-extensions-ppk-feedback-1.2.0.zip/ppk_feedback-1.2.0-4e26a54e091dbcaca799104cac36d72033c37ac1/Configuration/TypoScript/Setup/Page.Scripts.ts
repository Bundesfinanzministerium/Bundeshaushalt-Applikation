page {
    includeJS {
        ppkFeedback_10 = EXT:ppk_feedback/Resources/Public/Scripts/jquery.ppkFeedback.js
    }
    includeJSFooterlibs  {

    }
}
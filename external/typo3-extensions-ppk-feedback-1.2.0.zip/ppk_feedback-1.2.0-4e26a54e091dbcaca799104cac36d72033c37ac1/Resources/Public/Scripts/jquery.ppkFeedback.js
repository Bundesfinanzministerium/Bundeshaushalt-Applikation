
var ppkFeedback = ppkFeedback || {};

ppkFeedback.pi1 = {};
ppkFeedback.inProcess = false;

$(function() {

    $('.tx-ppk-feedback form').submit(function() {

        if ( ppkFeedback.inProcess )
            return false;

        // ppkFeedback.inProcess = true;
        ppkFeedback.pi1.requestAjax(this);

        return false;
    });

});

ppkFeedback.pi1.requestAjax = function(objForm) {

    var objPluginDiv = ppkFeedback.getPluginDiv(objForm);

    if ( objPluginDiv ) {

        $(".tx-ppk-feedback fieldset p").addClass('loading');
        $(".tx-ppk-feedback fieldset p span").html('bitte warten...');

        var pId    = $('input.pId', objPluginDiv).val();
        var datas  = $(objForm).serialize();
        var objPar = $(objPluginDiv).parent();

        // datas = datas.replace(/ppkFeedback_pi1/gi,"ppkFeedback_pi2");

        $.ajax({
            data:     datas,
            type:     'POST',
            url:      'index.php?eID=ppkFeedback',
            dataType: 'json',
            success:  ppkFeedback.success,
            error:    ppkFeedback.error
        });

    }

};

ppkFeedback.success = function(  data, textStatus, jqXHR  ) {

    $(".tx-ppk-feedback fieldset p").removeClass('loading');
    $(".tx-ppk-feedback fieldset p span").html();

    if ( data.status == 'error' ) {

        var errMsg = '';
        errMsg += "<div class=\"error\">";
        errMsg += "<h2>Es sind Fehler aufgetreten.<br />Bitte überprüfen Sie die folgenden Felder:</h2>";
        errMsg += "<ul class=\"error\">";

        $(".tx-ppk-feedback *").removeClass('error');

        $.each(data.errors, function( key, value ) {
            $(".tx-ppk-feedback #" + value.field).addClass('error');
            errMsg += "<li><a href='#' class='" + value.field + "'>" + value.message + "</a></li>";
        })

        errMsg += "</ul>";
        errMsg += "</div>";
        errMsg += "<hr />";

        $(".tx-ppk-feedback .messages").html(errMsg);
        $(".tx-ppk-feedback fieldset p span").html('Bitte überprüfen Sie die markierten Felder.');
        $(".tx-ppk-feedback fieldset p").addClass('error');


        $('#ppkFeedback .error a.topic').click(function(){ $('#topic').focus(); return false; });
        $('#ppkFeedback .error a.name').click(function(){ $('#name').focus(); return false; });
        $('#ppkFeedback .error a.email').click(function(){ $('#email').focus(); return false; });
        $('#ppkFeedback .error a.message').click(function(){ $('#message').focus(); return false; });
        $('#ppkFeedback .error a.termsAccepted').click(function(){ $('#termsAccepted').focus(); return false; });

        $('.tx-ppk-feedback .messages').attr("tabindex",-1).focus();

    } else {
        $(".tx-ppk-feedback .messages").hide();
        $(".tx-ppk-feedback .messages").html('<div class="thanks"><h2>Vielen Dank</h2><p>Ihre Nachricht wurde übermittelt.</p></div>');
        $(".tx-ppk-feedback form").fadeOut(250,function(){
            $(".tx-ppk-feedback .messages").fadeIn(250, function() {
                $('.tx-ppk-feedback .messages').attr("tabindex",-1).focus();
            });
        });
    }

    ppkFeedback.inProcess = false;

}

ppkFeedback.error = function(  jqXHR, textStatus, errorThrown  ) {

    /*
    console.log('ppkFeedback.error( jqXHR, textStatus, errorThrown )');
    console.log(jqXHR);
    console.log(textStatus);
    console.log(errorThrown);
    */

}

ppkFeedback.getPluginDiv = function( obj ) {

    var parentObj = $(obj);

    for ( var i = 0; i <= 10; i++ ) {
        parentObj = parentObj.parent();
        if ( parentObj.hasClass('tx-ppk-feedback') )
            return parentObj;
    }

    return false;

}

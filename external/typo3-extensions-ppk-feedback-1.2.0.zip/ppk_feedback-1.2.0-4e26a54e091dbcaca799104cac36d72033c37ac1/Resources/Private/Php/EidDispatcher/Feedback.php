<?php

/**
 * Configure extension parameter
 */
$vendorName = 'PPKOELN';
$extensionName = 'PpkFeedback';
$pluginName = 'Pi1';
$controllerName = 'Feedback';
$controllerActionName = 'ajax';

/**
 * Gets the Ajax Call Parameters
 */
$api = \TYPO3\CMS\Core\Utility\GeneralUtility::_GP('tx_ppkfeedback_pi1');

/**
 * Bootsprap extension
 *
 * @var \TYPO3\CMS\Frontend\Controller\TypoScriptFrontendController $GLOBALS['TSFE']
 */
$GLOBALS['TSFE'] = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Frontend\\Controller\\TypoScriptFrontendController', $GLOBALS['TYPO3_CONF_VARS'], null, 0);
\TYPO3\CMS\Frontend\Utility\EidUtility::initLanguage($api['lang']);

$GLOBALS['TSFE']->connectToDB();
$GLOBALS['TSFE']->initFEuser();
\TYPO3\CMS\Frontend\Utility\EidUtility::initTCA();

$GLOBALS['TSFE']->checkAlternativeIdMethods();
$GLOBALS['TSFE']->clear_preview();
$GLOBALS['TSFE']->determineId();
$GLOBALS['TSFE']->initTemplate();
$GLOBALS['TSFE']->getConfigArray();
$GLOBALS['TSFE']->cObj = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Frontend\\ContentObject\\ContentObjectRenderer');

$bootstrap = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Core\\Bootstrap');

$GLOBALS['TSFE']->settingLanguage();
$GLOBALS['TSFE']->settingLocale();

/**
 * Prepare Object Manager
 *
 * @var \TYPO3\CMS\Extbase\Object\ObjectManager $objectManager
 */
$objectManager = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Object\\ObjectManager');

/**
 * Initialize Extbase bootstap
 *
 * @var \TYPO3\CMS\Extbase\Core\Bootstrap $bootstrap
 */
// $bootstrap = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Extbase\\Core\\Bootstrap');
$bootstrap->initialize(array(
    'extensionName' => $extensionName,
    'pluginName' => $pluginName,
    'vendorName' => $vendorName
));
$bootstrap->cObj = \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance('TYPO3\\CMS\\Frontend\\ContentObject\\ContentObjectRenderer');

/**
 * Prepare request
 *
 * @var \TYPO3\CMS\Extbase\Mvc\Request $request
 */
$request = $objectManager->get('TYPO3\\CMS\\Extbase\\Mvc\\Request');
$request->setControllerVendorName($vendorName);
$request->setcontrollerExtensionName($extensionName);
$request->setPluginName($pluginName);
$request->setControllerName($controllerName);
$request->setControllerActionName($controllerActionName);
$request->setArguments($api);

/**
 * Prepare response
 *
 * @var \TYPO3\CMS\Extbase\Mvc\ResponseInterface $response
 */
$response = $objectManager->get('TYPO3\\CMS\\Extbase\\Mvc\\ResponseInterface');

/**
 * Prepare dispatcher
 *
 * @var \TYPO3\CMS\Extbase\Mvc\Dispatcher $dispatcher
 */
$dispatcher = $objectManager->get('TYPO3\\CMS\\Extbase\\Mvc\\Dispatcher');
$dispatcher->dispatch($request, $response);

/**
 * Return results
 */
$ajaxReturnData = $response->getContent();

header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
header('Cache-Control: no-cache, must-revalidate');
header('Pragma: no-cache');
header('Content-Length: ' . strlen($ajaxReturnData));
header('Content-Type: application/json; charset=utf-8');
header('Content-Transfer-Encoding: 8bit');

echo $ajaxReturnData;

#Matomo Trakking für alle Seiten

Diese Extension integriert ein Matomo trakking JS-Snippet auf allen seiten.

Per Konstanten können Matomo Host und SiteId gesetzt werden

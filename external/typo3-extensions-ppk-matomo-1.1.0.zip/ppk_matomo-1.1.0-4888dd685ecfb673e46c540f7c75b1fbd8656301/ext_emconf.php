<?php

$EM_CONF[$_EXTKEY] = array(
    'title' => 'PPK: Matomo',
    'description' => 'Matomo plugin',
    'category' => 'templates',
    'author' => 'Christian Rath',
    'author_email' => 'christian.rath@publicispixelpark.de',
    'author_company' => 'Publicis Pixelpark Köln',
    'shy' => '',
    'priority' => '',
    'module' => '',
    'state' => 'stable',
    'internal' => '',
    'uploadfolder' => '0',
    'createDirs' => '',
    'modify_tables' => '',
    'clearCacheOnLoad' => 0,
    'lockType' => '',
    'version' => '1.1.0',
    'constraints' => array(
        'depends' => array(
            'typo3' => '6.2.0-9.9.99',
        ),
        'conflicts' => array(),
        'suggests' => array(),
    ),
);
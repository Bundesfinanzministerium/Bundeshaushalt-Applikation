<?php

if (!defined('TYPO3_MODE')) {
    die ('Access denied.');
}

/*************************************************************************
 * Register plugins
 */
\TYPO3\CMS\Extbase\Utility\ExtensionUtility::registerPlugin(
    'PPK.' . $_EXTKEY,
    'Code',
    'Trakking Snippet'
);

/***************
 * Default TypoScript
 */
\TYPO3\CMS\Core\Utility\ExtensionManagementUtility::addStaticFile(
    $_EXTKEY,
    'Configuration/TypoScript',
    'PPK: Matomo'
);

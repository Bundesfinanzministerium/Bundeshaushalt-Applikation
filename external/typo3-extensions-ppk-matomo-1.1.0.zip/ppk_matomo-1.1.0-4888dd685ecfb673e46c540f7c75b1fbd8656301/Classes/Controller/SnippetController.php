<?php
namespace PPK\PpkMatomo\Controller;

/***************************************************************
 *
 *  Copyright notice
 *
 *  (c) 2019 Christian Rath <christian.rath@publicispixelpark.de>, Pixelpark AG
 *
 *  All rights reserved
 *
 *  This script is part of the TYPO3 project. The TYPO3 project is
 *  free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  The GNU General Public License can be found at
 *  http://www.gnu.org/copyleft/gpl.html.
 *
 *  This script is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  This copyright notice MUST APPEAR in all copies of the script!
 ***************************************************************/

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

class SnippetController extends ActionController
{

    /**
     * Render action
     * 
     * @return string
     */
    public function renderAction()
    {



        if ((int)$GLOBALS['TSFE']->id == (int)$this->settings['pids']['homepage']) {
            $pagename = '__INDEX__' . $GLOBALS['TSFE']->page['title'];
            $url = $this->settings['host'];
            $areas = $this->settings['language'] . '/' . $GLOBALS['TSFE']->page['title'];
        } else {
            $pagename = $GLOBALS['TSFE']->page['title'];
            $url = $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
            $areas = $this->settings['language'] . $_SERVER['REQUEST_URI'];
        }
        $pagename = $this->removeTrailingSlash($pagename);
        $url = $this->removeTrailingSlash($url);
        $areas = $this->removeTrailingSlash($areas);

        // assign to view
        $this->view->assign('piwik_idsite',
            $this->settings['piwik_idsite']
        );

        $this->view->assign('piwik_host',
            $this->removeTrailingSlash($this->settings['piwik_host'])
        );

        $this->view->assign('pagename', array(
            'plain' => $pagename,
            'encoded' => urlencode($pagename)
        ));

        $this->view->assign('areas', array(
            'plain' => $areas,
            'encoded' => urlencode($areas)
        ));

        $this->view->assign('url', array(
            'plain' => $url,
            'encoded' => urlencode($url)
        ));
    }

    protected function removeTrailingSlash($argument = '')
    {
        $argument = trim($argument);
        $lastChar = substr($argument, strlen($argument) - 1, 1);
        if ($lastChar == '/') {
            $argument = substr($argument, 0, strlen($argument) - 1);
        }
        return $argument;
    }
}
